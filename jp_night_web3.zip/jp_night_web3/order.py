from pydantic import BaseModel, Field

from jp_night_web3.common import Response


class PurchaseNftRequest(BaseModel):
    appName: int = Field(description="渠道名称")
    nftActivityName: str = Field(description="购买的nft的项目名称")
    price: int = Field(description="价格")
    amount: int = Field(description="购买数量")
    euserId: int = Field(description="外部用户Id")
    enftId: int = Field(description="外部nft 活动Id")


def purchase_nft(request: PurchaseNftRequest) -> Response:
    """
    app向web3 server推送购买nft请求, web3 server会将订单初始化为pending状态，由web3 server后端进行nft发放
    """
    raise NotImplementedError
