import types

from pydantic import BaseModel


class Response(BaseModel):
    code: int = 0
    msg: str = "ok"
    data: dict



