from pydantic import BaseModel, Field, model_validator, EmailStr

from jp_night_web3.common import Response


class BaseUserModel(BaseModel):
    euserId: int = Field(description="外部userID")
    appName: str = Field(description="来源渠道")


class RegisterRequest(BaseUserModel):
    """
    邮箱和手机号至少一个存在
    """

    euserName: str = Field(description="外部userName")
    email: EmailStr | None = Field(description="用户邮箱")
    phone: str | None = Field(description="手机号")

    @model_validator(mode="after")
    def validate_email_phone(self):
        if not self.email and not self.phone:
            raise ValueError("邮箱和手机号至少一个存在")


class UpdateUserRequest(BaseUserModel):
    euserName: str | None = Field(description="外部userName")
    email: EmailStr | None = Field(description="用户邮箱")
    phone: str | None = Field(description="手机号")


def register_web3_account(request: RegisterRequest) -> Response:
    """
    在web3server中注册，并为用户生成绑定web3地址
    """
    raise NotImplementedError


def update_user(request: UpdateUserRequest) -> Response:
    """
    更新web3server 中的用户信息，不同平台的不同的手机号或邮箱视为不同的用户
    """
    raise NotImplementedError


def delete_user(request: BaseUserModel) -> Response:
    """
    根据email以及渠道删除用户，删除为软删除
    """
    raise NotImplementedError


def login(request: BaseUserModel) -> Response:
    """web3登录接口，若已有地址，直接返回，若没有web3地址，生成并绑定web3地址"""
    raise NotImplementedError
