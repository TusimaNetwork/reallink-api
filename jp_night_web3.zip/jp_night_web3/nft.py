from pydantic import BaseModel, Base64Str, Field

from jp_night_web3.common import Response


class AddActivityRequest(BaseModel):
    nftActivityName: str = Field(description="活动名称")
    imageFileName: str = Field(description="图片文件名称")
    appName: str = Field(description="渠道名称")
    enftId: int = Field(description="外部nft活动id")
    imageFileContent: Base64Str = Field(description="图片base64编码")


class UpdateActivityRequest(BaseModel):
    nftActivityName: str | None = Field(description="活动名称")
    appName: str = Field(description="渠道名称")
    enftId: int = Field(description="外部nft活动id")
    imageFileContent: Base64Str | None = Field(description="图片base64编码")


class DeleteActivityRequest(BaseModel):
    appName: str = Field(description="渠道名称")
    enftId: int = Field(description="外部nft活动id")


def add_activity(request: AddActivityRequest) -> Response:
    """
    app方增加nft activity的能力
    """
    raise NotImplementedError


def update_activity(request: UpdateActivityRequest) -> Response:
    """
    修改nft activity
    """
    raise NotImplementedError


def delete_activity(request: DeleteActivityRequest) -> Response:
    """
    删除nft activity
    """
    raise NotImplementedError
